// 2. write a program to print multiplication table of given number

var readlineSync = require("readline-sync");

let n = readlineSync.question("Enter the number : ")

for(let i=1;i<=10;i++){
    console.log(i+"*"+n+"="+z*i);
}