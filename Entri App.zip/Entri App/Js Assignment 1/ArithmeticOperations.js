// find the answers of given questions and console it ()

// Addition 23+34
let a =23;
let b = 34;

console.log(a+b)

//substraction 55-36
let c=55;
let d=36;
let e=c-d;
console.log(c ,"-", d ,"= ",e)

//mutiplication 34*25

let f = 34;
let g = 25;
h = f * g;
console.log( f,"*",g,"=",h)

// division 15/5

let i=15;
let j=5;
k=i/j;
console.log(i,"/",j,"=",k )



// remainder 17%3

let l =17;
let m= 3;
n=17%3;
console.log(l,"%",m,"=",n)


// problem 45+34*23-3
let p = 45;
let q =3
R=p+b*e-q
console.log(p,"+",b,"*",e,"-",q,"=",R)