// Check whether the student has passed or failed in the exam  
// Marks
// Sub1: 70
// Sub2:80 
// Sub3:90
// Sub4:50 
// if the total mark is greater than 250 then show as passed else console as failed 

let sub1 =70;
let sub2 = 80;
let sub3 = 90;
let sub4 = 50;

let total = sub1+ sub2+sub3+sub4;

if(total>250)
    {
        console.log("Passed")
    }
else
    {
        console.log("Failed")
    }